#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "fila.h"

//Verifica se a fila est� cheia 
bool estaCheio(Fila* f)
{
   return ((f->fim + 1) % MAX == f->inicio);
}

//Verifica se a fila est� vazia 
bool estaVazio(Fila* f)
{
   return (f->inicio == f->fim);
}

//Enfileira um novo item 
bool enfileirar(char* x, Fila* f)
{
   if (estaCheio(f))
   {
      printf("A fila esta cheia.\n");
      return false;
   }
   strcpy(f->itens[f->fim], x); //copia a string para a posi��o
   f->fim = (f->fim + 1) % MAX; //avan�a circularmente 
   return true;
}

//remove um elemento da fila 
char* desenfileirar(Fila* f)
{
   if (estaVazio(f))
   {
      printf("A fila esta vazia.\n");
      return NULL;
   }
   char* x = f->itens[f->inicio]; //pega a string na frente
   f->inicio = (f->inicio + 1) % MAX;
   return x;
}

//imprime todos os elementos na fila 
void imprimeFila(Fila* f)
{
   if (estaVazio(f))
   {
      printf("A fila esta vazia.\n");
      return;
   }
   printf("Fila do inicio ate o fim: ");
   int i = f->inicio;
   while (i != f->fim)
   {
      printf("%s ", f->itens[i]);
      i = (i + 1) % MAX;
   }
   printf("\n");
}

