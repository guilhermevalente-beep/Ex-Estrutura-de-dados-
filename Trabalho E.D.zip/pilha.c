#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "pilha.h"

//Inicializa a pilha, come�a vazia 
void inicializar(Pilha* p)
{
   p->topo = NULL;
}

//Verifica se a pilha est� vazia 
bool pilhaEstaVazio(Pilha* p)
{
   return p->topo == NULL;
}

//Empilha um novo item na pilha 
bool empilhar(ItemPilha x, Pilha* p)
{
   No* novo = (No*) malloc(sizeof(No)); //Cria um novo espa�o de mem�ria
   if (novo == NULL)
   {
      printf("Erro de alocacao!\n");
      return false;
   }
   novo->dado = x; //guarda valor 
   novo->prox = p->topo; //aponta para o antigo topo
   p->topo = novo; //atualiza o topo
   return true;
}

//Retira o item que foi colocado por ultimo na pilha e atualiza o topo
ItemPilha desempilhar(Pilha* p) 
{
   if (pilhaEstaVazio(p))
   {
      printf("A pilha esta vazia.\n");
      return -1;
   }
   No* temp = p->topo; //guarda o topo anterior 
   ItemPilha valor = temp->dado; 
   p->topo = temp->prox; //Move o topo para o proximo n� 
   free(temp); //libera mem�ria 
   return valor; //retorna o item que foi retirado
}

//Imprime todos os itens que foram armazenados na pilha 
void imprimePilha(Pilha* p)
{
   if (pilhaEstaVazio(p))
   {
      printf("A pilha esta vazia.\n");
      return;
   }
   printf("Pilha do topo ate a base: ");
   No* atual = p->topo;
   while (atual != NULL)
   {
      printf("%d ", atual->dado);
      atual = atual->prox;
   }
   printf("\n");
}

