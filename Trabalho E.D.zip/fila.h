#ifndef FILA_H
#define FILA_H

#include <stdbool.h>

#define MAX 100

//Define o tipo de item que vai ser armazenado na fila (caracteres)
typedef char ItemFila[10];

//Estrutura para a fila 
typedef struct fila
{
   int inicio; //posi��o do primeiro elemento
   int fim; //pposi��o do ultimo elemento
   ItemFila itens[MAX]; //array de strings 
} Fila;

bool estaCheio(Fila* f);
bool estaVazio(Fila* f);
bool enfileirar(char* x, Fila* f);
char* desenfileirar(Fila* f);
void imprimeFila(Fila* f);

#endif

