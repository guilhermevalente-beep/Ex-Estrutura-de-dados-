#ifndef RPN_H
#define RPN_H

#include "fila.h"
#include "pilha.h"

//Fun��o principal: avalia a express�o polonesa reversa e calcula o resultado
int avaliarRPN(Fila* f);

#endif

