#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "rpn.h"

//aplica um operador a dois operandos 
int aplicarOperador(int a, int b, char op)
{
   switch (op)
   {
      case '+': return a + b;
      case '-': return a - b;
      case '*': return a * b;
      case '/':
         if (b == 0)
         {
            printf("Erro: divisao por zero!\n");
            exit(1);
         }
         return a / b;
      default:
         printf("Operador invalido: %c\n", op);
         exit(1);
   }
}

//Avalia a express�o usando a fila de tokens e a pilha encadeada 
int avaliarRPN(Fila* f)
{
   Pilha p;
   inicializar(&p);

   //avalia cada token da fila 
   while (!estaVazio(f))
   {
      char* token = desenfileirar(f);

      if (isdigit(token[0]))  // se come�a com n�mero
      {
         empilhar(atoi(token), &p);
      }
      else  // operador
      {
         int b = desempilhar(&p);
         int a = desempilhar(&p);
         int res = aplicarOperador(a, b, token[0]);
         empilhar(res, &p);
      }
   }

   return desempilhar(&p);  //retorna o resultado (ultimo item que foi armazenado na pilha)
}

