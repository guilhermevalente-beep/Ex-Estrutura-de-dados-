#ifndef PILHA_H
#define PILHA_H

#include <stdbool.h>

//Define o tipo de item que pode ser armazenado na pilha (apenas inteiros)
typedef int ItemPilha;

//estrutura para um n� da pilha encadeada
typedef struct No
{
   ItemPilha dado; //Item armazenado no local
   struct No* prox; //Ponteiro que aponta para o n� seguinte 
} No;

//Estrutura para a pilha
typedef struct
{
   No* topo; //Topo da pilha
} Pilha;

void inicializar(Pilha* p);
bool pilhaEstaVazio(Pilha* p);
bool empilhar(ItemPilha x, Pilha* p);
ItemPilha desempilhar(Pilha* p);
void imprimePilha(Pilha* p);

#endif

