#include <stdio.h>
#include <string.h>
#include "fila.h"
#include "rpn.h"

//Programa principal 
int main()
{
   Fila f;
   f.inicio = 0;
   f.fim = 0;

   char entrada[200];
   printf("Digite a expressao em RPN (Separe cada termo com espaco): ");
   fgets(entrada, sizeof(entrada), stdin); //usado para armazenar a string no lugar do scanf, pois aceita os espa�os em branco 

   //divide a string de entrada em tokens (separados por espa�o)
   char* token = strtok(entrada, " \n");
   while (token != NULL)
   {
      enfileirar(token, &f);
      token = strtok(NULL, " \n");
   }
   
   //avalia a expres�o
   int resultado = avaliarRPN(&f);
   printf("Resultado = %d\n", resultado);

   return 0;
}

